# Timer CLI

This timer is created by me just for learning

## Usage

Open your terminal and type:

tmrz [arg(number)]

Example:
```
tmrz 20
```
