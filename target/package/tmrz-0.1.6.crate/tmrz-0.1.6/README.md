# Timer CLI

This timer is created by me just for learning. After the timer is done, 
You will get notification.

## Usage

Open your terminal and type:

tmrz [arg(number)]
Note: number in seconds

Example:
```
tmrz 20
```
