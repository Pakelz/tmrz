# Timer CLI

This timer is created by me just for learning

## Usage

Open your terminal and type:

timer_by_pakel [arg(number)]

Example:
```
timer_by_pakel [arg(number)]
```
