# Timer CLI

This timer is created by me just for learning

## Usage

Open your terminal and type:

tmr [arg(number)]

Example:
```
tmr 20
```
